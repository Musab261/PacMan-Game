package Game;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.sound.sampled.*;
import java.io.*;
import java.util.Random;


public class Pacman extends JPanel implements KeyListener {
	private final int CELL_SIZE = 25;
    private final int[][] map = {
            {  3,  1,  1,  1,  1,  1,  1,  1,  1, 36,  1,  1,  1,  1,  1,  1,  1,  1,  4},
            {  2,  0,  0,  0,  0,  0,  0,  0,  0,  2,  0,  0,  0,  0,  0,  0,  0,  0,  2},  
            {  2,  0, 18, 17,  0, 18, 32, 17,  0,  2,  0, 18, 32, 17,  0, 18, 17,  0,  2},   
            {  2, 39, 19, 20,  0, 19, 31, 20,  0, 11,  0, 19, 31, 20,  0, 19, 20, 39,  2},  
            {  2,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  2},    
            {  2,  0, 12, 13,  0, 14,  0, 12,  1, 36,  1, 13,  0, 14,  0, 12, 13,  0,  2},   
            {  2,  0,  0,  0,  0,  2,  0,  0,  0,  2,  0,  0,  0,  2,  0,  0,  0,  0,  2},   
            {  5,  1,  1,  4,  0, 38,  1, 13,  0, 11,  0, 12,  1, 37,  0,  3,  1,  1,  6},      
            { -1, -1, -1,  2,  0,  2,  0,  0,  0,  0,  0,  0,  0,  2,  0,  2, -1, -1, -1},    
            {  3,  1,  1,  6,  0, 11,  0,  3,  1,  1,  1,  4,  0, 11,  0,  5,  1,  1,  4},
            {  5,  1,  1,  4,  0,  0,  0,  2, -1, -1, -1,  2,  0,  0,  0,  3,  1,  1,  6},
            { -1, -1, -1,  2,  0, 14,  0,  5,  1,  1,  1,  6,  0, 14,  0,  2, -1, -1, -1},
            {  3,  1,  1,  6,  0, 11,  0,  0,  0,  0,  0,  0,  0, 11,  0,  5,  1,  1,  4},
            {  2,  0,  0,  0,  0,  0,  0, 12,  1, 36,  1, 13,  0,  0,  0,  0,  0,  0,  2},
            {  2, 39, 12,  4,  0,  0,  0,  0,  0,  2,  0,  0,  0,  0,  0,  3, 13, 39,  2},
            {  2,  0,  0,  2,  0, 12,  1, 13,  0, 11,  0, 12,  1, 13,  0,  2,  0,  0,  2},
            { 38, 13,  0, 11,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 11,  0, 12, 37},
            {  2,  0,  0,  0,  0,  0,  0, 12,  1, 36,  1, 13,  0,  0,  0,  0,  0,  0,  2},
            {  2,  0,  0,  0, 14,  0,  0,  0,  0,  2,  0,  0,  0,  0, 14,  0,  0,  0,  2},
            {  2,  0, 12,  1, 35,  1,  1, 13,  0, 11,  0, 12,  1,  1, 35,  1, 13,  0,  2},
            {  2,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  2},
            {  5,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  6}     
    };        
            
            //  1 for wallupdownImage
            //  2 for wallleftrightImage
            //  3 for wallupperleftcornerImage
            //  4 for wallupperrightcornerImage
            //  5 for walllowerleftcornerImage
            //  6 for walllowerrightcornerImage
            //  7 for wallushapeupImage    
            //  8 for wallushaperightImage
            //  9 for wallushapeleftImage
            // 10 for wallushapedownImage
            // 11 for wallnshapeupImage
            // 12 for wallnshaperightImage
            // 13 for wallnshapeleftImage                                          
            // 14 for wallnshapedownImage                                          
            // 15 for wallcircleImage                                         
            // 16 for wall4sideImage                                          
            // 17 for walluprightLImage                                          
            // 18 for wallupleftLImage
            // 19 for wallleftdownLImage
            // 20 for walldownrightLImage
            // 21 for wall2siderightupleftdownImage
            // 22 for wall2sideleftuprightdownImage                                          
            // 23 for wall1sideleftdownImage                                          
            // 24 for wall1sideleftupImage                                          
            // 25 for wall1siderightdownImage                                          
            // 26 for wall1siderightupImage                                          
            // 27 for wallnoleftdownsideImage                                          
            // 28 for wallnoleftupsideIma 
            // 29 for wallnorightdownsideImage                                      
            // 30 for wallnorightupsideImage                                          
            // 31 for wallbottomlineImage
            // 32 for walluplineImage
            // 33 for wallleftlineImage
            // 34 for wallrightlineImage 
            // 35 for wallbottomline2cornerImage
            // 36 for wallupline2cornerImage
            // 37 for wallrightline2cornerImage
            // 38 for wallleftline2cornerImage
            // 39 for superfood
    

    private int pacmanX = 1;
    private int pacmanY = 1;
    private int ghostX = 9;
    private int ghostY = 8;
    private int score = 0;
    final int Xpacman = pacmanX;
    final int Ypacman = pacmanY;
    final int Xghost = ghostX;
    final int Yghost = ghostY;
    int count = -1;
    int a = 1; 
    int c = 0;
    int d = 0;
    int b;
    private Image ghostImage;
    private Image superFoodImage;

    private Image wallupdownImage;
    private Image wallleftrightImage;
    private Image wallupperleftcornerImage;
    private Image wallupperrightcornerImage;
    private Image walllowerleftcornerImage;
    private Image walllowerrightcornerImage;
    private Image wallushapeupImage;
    private Image wallushaperightImage;
    private Image wallushapeleftImage;
    private Image wallushapedownImage;
    private Image wallnshapeupImage;
    private Image wallnshaperightImage;
    private Image wallnshapeleftImage;
    private Image wallnshapedownImage;
    private Image wallcircleImage;
    private Image wall4sideImage;    
    private Image walluprightLImage;
    private Image wallupleftLImage;
    private Image wallleftdownLImage;
    private Image walldownrightLImage;
    private Image wall2siderightupleftdownImage;
    private Image wall2sideleftuprightdownImage;
    private Image wall1sideleftdownImage;
    private Image wall1sideleftupImage;
    private Image wall1siderightdownImage;
    private Image wall1siderightupImage;
    private Image wallnoleftdownsideImage;
    private Image wallnoleftupsideImage;
    private Image wallnorightdownsideImage;
    private Image wallnorightupsideImage;
    private Image wallbottomlineImage;
    private Image walluplineImage;
    private Image wallleftlineImage;
    private Image wallrightlineImage;
    private Image wallbottomline2cornerImage;
    private Image wallupline2cornerImage;
    private Image wallrightline2cornerImage;
    private Image wallleftline2cornerImage;
    
    public Pacman() {
        playStartingSound();
        Timer time = new Timer(3000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	b = 1;
            	if(d == 0) {
            	playBackgroundSound();
            	}
            }
        });
        time.start();
    	setPreferredSize(new Dimension(map[0].length * CELL_SIZE, map.length * CELL_SIZE));
        setBackground(Color.black);
        setFocusable(true);
        addKeyListener(this);
        loadImages(); // Load images
        Timer timer = new Timer(200, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              if(d == 0) {	
            	moveGhost();
                repaint();
              }
            }
        });
        timer.start();
    }
    
    private void playSound(String fileName) {
        try {
            AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File(fileName).getAbsoluteFile());// Open an audio input stream
            Clip clip = AudioSystem.getClip();// Get a clip resource
            clip.open(audioInputStream);      // Open audio clip and load samples from the audio input stream
            clip.start();                     // Start playing the clip
        } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
            e.printStackTrace();
        }
    }
    
    
    // Method to play the sound effect for Background
    private void playBackgroundSound() {
        playSound("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Sound\\Backgroundsound.wav"); 
    }
    
    // Method to play the sound effect for Winning
    private void playWinningSound() {
        playSound("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Sound\\Winningsound.wav"); 
    }
    
    // Method to play the sound effect for Starting
    private void playStartingSound() {
        playSound("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Sound\\Startingsound.wav"); 
    }
    
   // Method to play the sound effect for superFood
    private void playSuperFoodSound() {
        playSound("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Sound\\Superfoodsound.wav"); 
    }

    // Method to play the sound effect for eating a dot
    private void playDotSound() {
        playSound("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Sound\\Foodsound.wav"); 
    }

    // Method to play the sound effect for game over
    private void playGameOverSound() {
        playSound("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Sound\\Gameoversound.wav"); // Adjust the file name to match your sound file
    }
    
    
    // Load images
    private void loadImages() {
    	wallupdownImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wallupdown.png").getImage();
    	wallleftrightImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wallleftright.png").getImage();
    	wallupperleftcornerImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wallupperleftcorner.png").getImage();
    	wallupperrightcornerImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wallupperrightcorner.png").getImage();
    	walllowerleftcornerImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\walllowerleftcorner.png").getImage();
    	walllowerrightcornerImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\walllowerrightcorner.png").getImage();
    	wallushapeupImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wallushapeup.png").getImage();
    	wallushaperightImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wallushaperight.png").getImage();
    	wallushapeleftImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wallushapeleft.png").getImage();
    	wallushapedownImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wallushapedown.png").getImage();
    	wallnshapeupImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wallnshapeup.png").getImage();
    	wallnshaperightImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wallnshaperight.png").getImage();
    	wallnshapeleftImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wallnshapeleft.png").getImage();
    	wallnshapedownImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wallnshapedown.png").getImage();
    	wallcircleImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wallcircle.png").getImage();
    	wall4sideImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wall4side.png").getImage();
    	walluprightLImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\walluprightL.png").getImage();
    	wallupleftLImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wallupleftL.png").getImage();
    	wallleftdownLImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wallleftdownL.png").getImage();
    	walldownrightLImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\walldownrightL.png").getImage();
    	wall2siderightupleftdownImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wall2siderightupleftdown.png").getImage();
    	wall2sideleftuprightdownImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wall2sideleftuprightdown.png").getImage();
    	wall1sideleftdownImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wall1sideleftdown.png").getImage();
    	wall1sideleftupImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wall1sideleftup.png").getImage();
    	wall1siderightdownImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wall1siderightdown.png").getImage();
    	wall1siderightupImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wall1siderightup.png").getImage();
    	wallnoleftdownsideImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wallnoleftdownside.png").getImage();
    	wallnoleftupsideImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wallnoleftupside.png").getImage();
    	wallnorightdownsideImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wallnorightdownside.png").getImage();
    	wallnorightupsideImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wallnorightupside.png").getImage();
    	wallbottomlineImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wallbottomline.png").getImage();
    	walluplineImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wallupline.png").getImage();
    	wallleftlineImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wallleftline.png").getImage();
    	wallrightlineImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wallrightline.png").getImage();
    	wallbottomline2cornerImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wallbottomline2corner.png").getImage();
    	wallupline2cornerImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wallupline2corner.png").getImage();
    	wallrightline2cornerImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wallrightline2corner.png").getImage();
    	wallleftline2cornerImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\wallleftline2corner.png").getImage();
    	ghostImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\ghost.png").getImage();
        superFoodImage = new ImageIcon("C:\\Users\\adv\\eclipse-workspace\\firstProgram\\src\\Game\\Images\\superfood.png").getImage();
    }
    
    
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        for (int row = 0; row < map.length; row++) {
            for (int col = 0; col < map[0].length; col++) {
            	switch (map[row][col]) {
            	case 1 :{
            		g2d.drawImage(wallupdownImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 2 :{
            		g2d.drawImage(wallleftrightImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 3 :{
            		g2d.drawImage(wallupperleftcornerImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 4 :{
            		g2d.drawImage(wallupperrightcornerImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 5 :{
            		g2d.drawImage(walllowerleftcornerImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 6 :{
            		g2d.drawImage(walllowerrightcornerImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 7 :{
            		g2d.drawImage(wallushapeupImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 8 :{
            		g2d.drawImage(wallushaperightImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 9 :{
            		g2d.drawImage(wallushapeleftImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 10 :{
            		g2d.drawImage(wallushapedownImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
                case 11 :{
            		g2d.drawImage(wallnshapeupImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 12 :{
            		g2d.drawImage(wallnshaperightImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 13 :{
            		g2d.drawImage(wallnshapeleftImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 14 :{
            		g2d.drawImage(wallnshapedownImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 15 :{
            		g2d.drawImage(wallcircleImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 16 :{
            		g2d.drawImage(wall4sideImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
                case 17 :{
            		g2d.drawImage(walluprightLImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 18 :{
            		g2d.drawImage(wallupleftLImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 19 :{
            		g2d.drawImage(wallleftdownLImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 20 :{
            		g2d.drawImage(walldownrightLImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 21 :{
            		g2d.drawImage(wall2siderightupleftdownImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 22 :{
            		g2d.drawImage(wall2sideleftuprightdownImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
                case 23 :{
            		g2d.drawImage(wall1sideleftdownImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 24 :{
            		g2d.drawImage(wall1sideleftupImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 25 :{
            		g2d.drawImage(wall1siderightdownImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 26 :{
            		g2d.drawImage(wall1siderightupImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 27 :{
            		g2d.drawImage(wallnoleftdownsideImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 28 :{
            		g2d.drawImage(wallnoleftupsideImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
                case 29 :{
            		g2d.drawImage(wallnorightdownsideImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 30 :{
            		g2d.drawImage(wallnorightupsideImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 31 :{
            		g2d.drawImage(wallbottomlineImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 32 :{
            		g2d.drawImage(walluplineImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 33 :{
            		g2d.drawImage(wallleftlineImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 34 :{
            		g2d.drawImage(wallrightlineImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 35 :{
            		g2d.drawImage(wallbottomline2cornerImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 36 :{
            		g2d.drawImage(wallupline2cornerImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 37 :{
            		g2d.drawImage(wallrightline2cornerImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 38 :{
            		g2d.drawImage(wallleftline2cornerImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 39 :{ //superFood
                    g2d.drawImage(superFoodImage, col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);
                }break;
            	case 0 :{
            		if (row == Xpacman && col == Ypacman) {}
            		else {
                        g2d.setColor(Color.white);// Food
                        g2d.fillOval(col * CELL_SIZE+(CELL_SIZE/2), row * CELL_SIZE+(CELL_SIZE/2), 4 , 4 );
            		}
                }break;
            	case  -1 :{
                  	g2d.setColor(Color.black);
                    g2d.fillRect(col * CELL_SIZE, row * CELL_SIZE, CELL_SIZE , CELL_SIZE );
                }break;
            	}
            }
        }

        // Draw Pac-Man
        if (c == 0) {
           	g2d.setColor(Color.yellow);
            g2d.fillArc((pacmanX * CELL_SIZE)+2, (pacmanY * CELL_SIZE)+2, 3*(CELL_SIZE/4), 3*(CELL_SIZE/4), 30, 300);
        }
        
        if (c == 1) {
            g2d.setColor(Color.yellow);
            g2d.fillArc((pacmanX * CELL_SIZE)+2, (pacmanY * CELL_SIZE)+2, 3*(CELL_SIZE/4), 3*(CELL_SIZE/4), 210, 300);
        }
        
        if (c == 2) {
            g2d.setColor(Color.yellow);
            g2d.fillArc((pacmanX * CELL_SIZE)+2, (pacmanY * CELL_SIZE)+2, 3*(CELL_SIZE/4), 3*(CELL_SIZE/4), 300, 300);
        }
        
        if (c == 3) {
            g2d.setColor(Color.yellow);
            g2d.fillArc((pacmanX * CELL_SIZE)+2, (pacmanY * CELL_SIZE)+2, 3*(CELL_SIZE/4), 3*(CELL_SIZE/4), 120, 300);
        }
        
        // Draw Ghost
        g2d.drawImage(ghostImage, ghostX * CELL_SIZE, ghostY * CELL_SIZE, CELL_SIZE, CELL_SIZE, this);

        // Draw score
        g2d.setColor(Color.white);
        g2d.drawString("Score: " + score, 15, 15);
    }

    
    
    
    // making method for rendom ghost direction
    String ghostdirection = "up";
    String[] direction = {"left", "right", "up", "down"};
    Random random = new Random();
	void randomnumber() {
		int randomNumber = random.nextInt(4);
        ghostdirection = direction[randomNumber];
	}
	
	
    private void moveGhost() {
    	if(b == 1) {
    	   switch(ghostdirection) {
    	     case "left":{
    	    	 if (map[ghostY][ghostX - 1] == 0 || map[ghostY][ghostX - 1] == -1 || map[ghostY][ghostX - 1] == 39) {
    	    		   ghostX--;
    	    		   if (map[ghostY - 1][ghostX] == 0 || map[ghostY - 1][ghostX] == -1 || map[ghostY - 1][ghostX] == 39) {
    	    			   randomnumber();
                       }
    	    		   if (map[ghostY + 1][ghostX] == 0 || map[ghostY + 1][ghostX] == -1 || map[ghostY + 1][ghostX] == 39) {
    	    			   randomnumber();
                       }
                 }else {
                	 randomnumber();
                 }
    	     }break;
             case "right":{
            	 if (map[ghostY][ghostX + 1] == 0 || map[ghostY][ghostX + 1] == -1 || map[ghostY][ghostX + 1] == 39) {
            		   ghostX++;
            		   if (map[ghostY - 1][ghostX] == 0 || map[ghostY - 1][ghostX] == -1 || map[ghostY - 1][ghostX] == 39) {
            			   randomnumber();
                       }
    	    		   if (map[ghostY + 1][ghostX] == 0 || map[ghostY + 1][ghostX] == -1 || map[ghostY + 1][ghostX] == 39) {
    	    			   randomnumber();
                       }
                 }else {
                	 randomnumber();
                 }
    	     }break;
             case "up":{
            	 if (map[ghostY - 1][ghostX] == 0 || map[ghostY - 1][ghostX] == -1 || map[ghostY - 1][ghostX] == 39) {
            		   ghostY--;
            		   if (map[ghostY][ghostX - 1] == 0 || map[ghostY][ghostX - 1] == -1 || map[ghostY][ghostX - 1] == 39) {
            			   randomnumber();
            		   }
            		   if (map[ghostY][ghostX + 1] == 0 || map[ghostY][ghostX + 1] == -1 || map[ghostY][ghostX + 1] == 39) {
            			   randomnumber();
            		   }	   
                 }else {
                	 randomnumber();
                 }
    	     }break;
             case "down":{ 
            	 if (map[ghostY + 1][ghostX] == 0 || map[ghostY + 1][ghostX] == -1 || map[ghostY + 1][ghostX] == 39) {
            		   ghostY++;
            		   if (map[ghostY][ghostX - 1] == 0 || map[ghostY][ghostX - 1] == -1 || map[ghostY][ghostX - 1] == 39) {
            			   randomnumber();
            		   }
            		   if (map[ghostY][ghostX + 1] == 0 || map[ghostY][ghostX + 1] == -1 || map[ghostY][ghostX + 1] == 39) {
            			   randomnumber();
            		   }
                 }else {
                	 randomnumber();
                 }
             }break;
    	   }
    	
    	
    	// Check for collision with ghost
        if (pacmanX == ghostX && pacmanY == ghostY) {
        	d = 1;
        	playGameOverSound();
            JOptionPane.showMessageDialog(this, "Game Over! Score: " + score);
            System.exit(0);
        }
    
    }
}
    @Override
    public void keyPressed(KeyEvent e) {
        int keyCode = e.getKeyCode();
        switch (keyCode) {
            case KeyEvent.VK_UP:
                if (map[pacmanY - 1][pacmanX] == 0 || map[pacmanY - 1][pacmanX] == -1 || map[pacmanY - 1][pacmanX] == 39) {
                    pacmanY--;
                    c = 3 ;
                }
                break;
            case KeyEvent.VK_DOWN:
                if (map[pacmanY + 1][pacmanX] == 0 || map[pacmanY + 1][pacmanX] == -1 || map[pacmanY + 1][pacmanX] == 39) {
                    pacmanY++;
                    c = 2 ;
                }
                break;
            case KeyEvent.VK_LEFT:
                if (map[pacmanY][pacmanX - 1] == 0 || map[pacmanY][pacmanX - 1] == -1 || map[pacmanY][pacmanX - 1] == 39) {
                    pacmanX--;
                    c = 1 ;
                }
                break;
            case KeyEvent.VK_RIGHT:
                if (map[pacmanY][pacmanX + 1] == 0 || map[pacmanY][pacmanX + 1] == -1 || map[pacmanY][pacmanX + 1] == 39) {
                    pacmanX++;
                    c = 0 ;
                }
                break;
        }

        // Check for collision with ghost
        if (pacmanX == ghostX && pacmanY == ghostY) {
        	d = 1;
        	playGameOverSound();
            JOptionPane.showMessageDialog(this, "Game Over! Score: " + score);
            System.exit(0);
        }

        
        // Check total no of score in the board 
        if(a == 1) {
    		for (int i = 0; i < map.length; i++) {
                for (int j = 0; j < map[0].length; j++) {
                	if (map[i][j] == 0) {
                		count += 1;
                		a = 2;
                	}else {
                		if(map[i][j] == 39) {
                			count += 10;
                			a = 2;
                		}
                	}
                }
    		}    
    	}
        
        // Check for collision with food
        if (pacmanX == Xpacman && pacmanY == Ypacman) {}
        else {
         if (map[pacmanY][pacmanX] == 0) {
        	score += 10;
        	playDotSound();
        	map[pacmanY][pacmanX] = -1; // Mark food as eaten
        	if(score == count*10) {
        		d = 1;
        		playWinningSound();
        		JOptionPane.showMessageDialog(this, "You won! Score: " + score);
        	}
        }
       } 
        
     // Check for collision with super food
        if (map[pacmanY][pacmanX] == 39) {
        	score += 100;
        	playSuperFoodSound();
        	map[pacmanY][pacmanX] = -1; // Mark Super food as eaten
        	if(score == count*10) {
        		d = 1;
        		playWinningSound();
        		JOptionPane.showMessageDialog(this, "You won! Score: " + score);
        	}
        }	
        
        
        repaint();
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Pac-Man");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.add(new Pacman());
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        
    }
}